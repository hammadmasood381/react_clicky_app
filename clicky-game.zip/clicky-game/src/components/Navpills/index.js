export { default } from "./Navpills";
