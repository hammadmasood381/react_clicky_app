export { default } from "./ClickCard";
